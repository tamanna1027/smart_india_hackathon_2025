"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Heart, Send, Bot, User, Activity, Shield, Brain, Stethoscope, AlertCircle, Info } from "lucide-react"

interface Message {
  id: string
  content: string
  sender: "user" | "bot"
  timestamp: Date
  type?: "info" | "warning" | "normal"
}

const healthTopics = [
  { name: "Heart Disease", icon: Heart, color: "bg-red-100 text-red-700" },
  { name: "Diabetes", icon: Activity, color: "bg-blue-100 text-blue-700" },
  { name: "Mental Health", icon: Brain, color: "bg-purple-100 text-purple-700" },
  { name: "Preventive Care", icon: Shield, color: "bg-green-100 text-green-700" },
]

const quickQuestions = [
  "What are the symptoms of diabetes?",
  "How can I prevent heart disease?",
  "What are signs of depression?",
  "When should I see a doctor?",
]

export function HealthChatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "Hello! I'm your AI Health Assistant. I'm here to provide general health information and disease awareness. How can I help you today?",
      sender: "bot",
      timestamp: new Date(),
      type: "info",
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const botResponse = generateHealthResponse(content)
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: botResponse.content,
        sender: "bot",
        timestamp: new Date(),
        type: botResponse.type,
      }
      setMessages((prev) => [...prev, botMessage])
      setIsTyping(false)
    }, 1500)
  }

  const generateHealthResponse = (query: string): { content: string; type: "info" | "warning" | "normal" } => {
    const lowerQuery = query.toLowerCase()

    if (lowerQuery.includes("diabetes")) {
      return {
        content:
          "Diabetes is a chronic condition where blood sugar levels are too high. Common symptoms include increased thirst, frequent urination, fatigue, and blurred vision. Type 2 diabetes can often be prevented through healthy lifestyle choices like regular exercise, balanced diet, and maintaining a healthy weight. If you're experiencing symptoms, please consult with a healthcare professional for proper diagnosis and treatment.",
        type: "info",
      }
    }

    if (lowerQuery.includes("heart") || lowerQuery.includes("cardiac")) {
      return {
        content:
          "Heart disease is the leading cause of death globally. Risk factors include high blood pressure, high cholesterol, smoking, diabetes, and family history. Prevention strategies include regular exercise, heart-healthy diet (low in saturated fats, high in fruits and vegetables), not smoking, limiting alcohol, and managing stress. Warning signs of heart attack include chest pain, shortness of breath, and pain in arms, neck, or jaw. Seek immediate medical attention if experiencing these symptoms.",
        type: "warning",
      }
    }

    if (lowerQuery.includes("mental") || lowerQuery.includes("depression") || lowerQuery.includes("anxiety")) {
      return {
        content:
          "Mental health is just as important as physical health. Signs of depression include persistent sadness, loss of interest in activities, changes in appetite or sleep, and feelings of hopelessness. Anxiety may cause excessive worry, restlessness, and physical symptoms like rapid heartbeat. Treatment options include therapy, medication, lifestyle changes, and support groups. If you're having thoughts of self-harm, please contact a mental health crisis line or emergency services immediately.",
        type: "warning",
      }
    }

    if (lowerQuery.includes("prevent") || lowerQuery.includes("prevention")) {
      return {
        content:
          "Prevention is key to maintaining good health! Regular health screenings, vaccinations, healthy diet, regular exercise, adequate sleep (7-9 hours), stress management, and avoiding tobacco and excessive alcohol are fundamental. Annual check-ups can help detect issues early when they're most treatable. Specific preventive measures vary by age, gender, and risk factors.",
        type: "info",
      }
    }

    return {
      content:
        "I understand you're asking about health-related topics. While I can provide general health information for educational purposes, I cannot diagnose conditions or replace professional medical advice. For specific health concerns, symptoms, or medical questions, please consult with a qualified healthcare provider. Is there a particular health topic you'd like to learn more about?",
      type: "normal",
    }
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-80 bg-card border-r border-border p-6">
        <div className="flex items-center gap-2 mb-6">
          <div className="p-2 bg-primary rounded-lg">
            <Stethoscope className="h-6 w-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-semibold text-foreground">HealthBot AI</h1>
            <p className="text-sm text-muted-foreground">Disease Awareness Assistant</p>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <h3 className="text-sm font-medium text-foreground mb-3">Health Topics</h3>
            <div className="grid grid-cols-2 gap-2">
              {healthTopics.map((topic) => (
                <Button
                  key={topic.name}
                  variant="ghost"
                  className="h-auto p-3 flex flex-col items-center gap-2 text-xs"
                  onClick={() => handleSendMessage(`Tell me about ${topic.name.toLowerCase()}`)}
                >
                  <topic.icon className="h-5 w-5 text-primary" />
                  <span className="text-center leading-tight">{topic.name}</span>
                </Button>
              ))}
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="text-sm font-medium text-foreground mb-3">Quick Questions</h3>
            <div className="space-y-2">
              {quickQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="w-full text-left text-xs h-auto p-2 justify-start"
                  onClick={() => handleSendMessage(question)}
                >
                  {question}
                </Button>
              ))}
            </div>
          </div>

          <Separator />

          <div className="bg-muted/50 p-4 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
              <div className="text-xs text-muted-foreground">
                <p className="font-medium text-foreground mb-1">Medical Disclaimer</p>
                <p>
                  This AI provides general health information only. Always consult healthcare professionals for medical
                  advice, diagnosis, or treatment.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-card border-b border-border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-full">
                <Bot className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h2 className="font-semibold text-foreground">AI Health Assistant</h2>
                <p className="text-sm text-muted-foreground">Online • Ready to help</p>
              </div>
            </div>
            <Badge variant="secondary" className="bg-primary/10 text-primary">
              Disease Awareness
            </Badge>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4 max-w-4xl mx-auto">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.sender === "bot" && (
                  <div className="p-2 bg-primary/10 rounded-full h-fit">
                    <Bot className="h-4 w-4 text-primary" />
                  </div>
                )}

                <Card
                  className={`max-w-[70%] ${message.sender === "user" ? "bg-primary text-primary-foreground" : "bg-card"}`}
                >
                  <CardContent className="p-4">
                    {message.type && message.type !== "normal" && (
                      <div className="flex items-center gap-2 mb-2">
                        {message.type === "info" && <Info className="h-4 w-4 text-primary" />}
                        {message.type === "warning" && <AlertCircle className="h-4 w-4 text-orange-500" />}
                        <span className="text-xs font-medium uppercase tracking-wide">
                          {message.type === "info" ? "Health Info" : "Important"}
                        </span>
                      </div>
                    )}
                    <p className="text-sm leading-relaxed">{message.content}</p>
                    <p className="text-xs opacity-70 mt-2">
                      {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </CardContent>
                </Card>

                {message.sender === "user" && (
                  <div className="p-2 bg-muted rounded-full h-fit">
                    <User className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div className="flex gap-3 justify-start">
                <div className="p-2 bg-primary/10 rounded-full h-fit">
                  <Bot className="h-4 w-4 text-primary" />
                </div>
                <Card className="bg-card">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-1">
                      <div className="flex gap-1">
                        <div
                          className="w-2 h-2 bg-primary rounded-full animate-bounce"
                          style={{ animationDelay: "0ms" }}
                        />
                        <div
                          className="w-2 h-2 bg-primary rounded-full animate-bounce"
                          style={{ animationDelay: "150ms" }}
                        />
                        <div
                          className="w-2 h-2 bg-primary rounded-full animate-bounce"
                          style={{ animationDelay: "300ms" }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground ml-2">AI is typing...</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="bg-card border-t border-border p-4">
          <div className="max-w-4xl mx-auto">
            <form
              onSubmit={(e) => {
                e.preventDefault()
                handleSendMessage(inputValue)
              }}
              className="flex gap-2"
            >
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about symptoms, prevention, or health topics..."
                className="flex-1"
                disabled={isTyping}
              />
              <Button type="submit" disabled={!inputValue.trim() || isTyping} className="px-4">
                <Send className="h-4 w-4" />
              </Button>
            </form>
            <p className="text-xs text-muted-foreground mt-2 text-center">
              This AI provides general health information. Always consult healthcare professionals for medical advice.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
