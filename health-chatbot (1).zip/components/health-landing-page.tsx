"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import {
  Heart,
  Activity,
  Brain,
  Shield,
  Stethoscope,
  Users,
  Award,
  CheckCircle,
  ArrowRight,
  Play,
  Menu,
  X,
  Clock,
  MessageCircle,
  Facebook,
  Instagram,
} from "lucide-react"

const navigationItems = [
  { name: "Services", href: "#services" },
  { name: "Features", href: "#features" },
  { name: "About", href: "#about" },
  { name: "Resources", href: "#resources" },
  { name: "Contact", href: "#contact" },
]

const healthServices = [
  {
    icon: Heart,
    title: "Heart Disease Awareness",
    description: "Comprehensive information about cardiovascular health, risk factors, and prevention strategies.",
    color: "text-red-600",
  },
  {
    icon: Activity,
    title: "Diabetes Management",
    description: "Learn about diabetes types, symptoms, monitoring, and lifestyle management techniques.",
    color: "text-blue-600",
  },
  {
    icon: Brain,
    title: "Mental Health Support",
    description: "Mental wellness resources, depression awareness, and anxiety management guidance.",
    color: "text-emerald-600",
  },
  {
    icon: Shield,
    title: "Preventive Care",
    description: "Vaccination schedules, health screenings, and proactive wellness strategies.",
    color: "text-teal-600",
  },
]

const features = [
  "Available 24/7 - Round the Clock Support",
  "Early Disease Awareness and Prevention",
  "Evidence-Based Medical Information",
  "Personalized Health Insights",
  "Symptom Assessment Tools",
  "Preventive Care Reminders",
  "Health Risk Evaluations",
]

const partners = [
  { name: "WHO Guidelines", logo: "🏥" },
  { name: "Medical Research", logo: "🔬" },
  { name: "Health Analytics", logo: "📊" },
  { name: "Wellness Programs", logo: "💚" },
]

export function HealthLandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-600 rounded-lg">
                <Stethoscope className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">HealthBot AI</h1>
                <p className="text-xs text-gray-500">Advanced Health Solutions</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              {navigationItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-gray-700 hover:text-emerald-600 font-medium transition-colors"
                >
                  {item.name}
                </a>
              ))}
            </nav>

            {/* CTA Button */}
            <div className="hidden md:flex items-center gap-4">
              <Button
                variant="outline"
                className="border-emerald-600 text-emerald-600 hover:bg-emerald-50 bg-transparent"
                asChild
              >
                <Link href="/signin">Sign In</Link>
              </Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700">Get Started</Button>
            </div>

            {/* Mobile menu button */}
            <button className="md:hidden p-2" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-gray-200">
              <div className="space-y-2">
                {navigationItems.map((item) => (
                  <a
                    key={item.name}
                    href={item.href}
                    className="block px-4 py-2 text-gray-700 hover:text-emerald-600 hover:bg-gray-50 rounded-md"
                  >
                    {item.name}
                  </a>
                ))}
                <div className="px-4 pt-4 space-y-2">
                  <Button
                    variant="outline"
                    className="w-full border-emerald-600 text-emerald-600 bg-transparent"
                    asChild
                  >
                    <Link href="/signin">Sign In</Link>
                  </Button>
                  <Button className="w-full bg-emerald-600 hover:bg-emerald-700">Get Started</Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-emerald-50 to-teal-50 py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">
                  🚀 Advanced AI Health Technology
                </Badge>
                <h1 className="text-4xl lg:text-6xl font-bold text-balance">
                  <span className="text-gray-900">Innovate - </span>
                  <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                    Prevent -
                  </span>
                  <span className="bg-gradient-to-r from-teal-600 to-blue-600 bg-clip-text text-transparent">
                    Transform
                  </span>
                </h1>
                <h2 className="text-xl lg:text-2xl font-semibold text-gray-800">
                  Experience Advanced AI-Powered Health Awareness
                </h2>
                <p className="text-lg text-gray-600 leading-relaxed max-w-xl">
                  Welcome to HealthBot AI, where innovation meets healthcare. With cutting-edge AI technology and
                  comprehensive medical knowledge, we provide personalized health insights, disease awareness, and
                  preventive care guidance to help you make informed health decisions.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 text-lg">
                  Get Started Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-emerald-600 text-emerald-600 hover:bg-emerald-50 px-8 py-3 text-lg bg-transparent"
                >
                  <Play className="mr-2 h-5 w-5" />
                  View Demo
                </Button>
              </div>

              <div className="flex items-center gap-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">500K+</div>
                  <div className="text-sm text-gray-600">Users Helped</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">1M+</div>
                  <div className="text-sm text-gray-600">Health Queries</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">24/7</div>
                  <div className="text-sm text-gray-600">AI Support</div>
                </div>
              </div>
            </div>

            {/* Right Content - Health Dashboard Mockup */}
            <div className="relative">
              <div className="bg-white rounded-2xl shadow-2xl p-6 border border-gray-200">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-emerald-100 rounded-lg">
                    <Stethoscope className="h-6 w-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">AI Health Assistant</h3>
                    <p className="text-sm text-gray-500">Online • Ready to help</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-200">
                    <p className="text-sm text-emerald-800">
                      "What are the early signs of diabetes I should watch for?"
                    </p>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-start gap-3">
                      <div className="p-1 bg-emerald-100 rounded-full">
                        <Stethoscope className="h-4 w-4 text-emerald-600" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-700 leading-relaxed">
                          Early diabetes symptoms include increased thirst, frequent urination, unexplained weight loss,
                          fatigue, and blurred vision. If you're experiencing these symptoms, I recommend consulting
                          with a healthcare professional...
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mt-6">
                  {healthServices.slice(0, 4).map((service, index) => (
                    <div key={index} className="p-3 bg-gray-50 rounded-lg text-center">
                      <service.icon className={`h-6 w-6 mx-auto mb-2 ${service.color}`} />
                      <p className="text-xs font-medium text-gray-700">{service.title}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 bg-emerald-600 text-white p-3 rounded-full shadow-lg">
                <Heart className="h-6 w-6" />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-teal-600 text-white p-3 rounded-full shadow-lg">
                <Shield className="h-6 w-6" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Comprehensive Health Services</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our AI-powered platform provides expert guidance across multiple health domains, helping you stay informed
              and make better health decisions.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {healthServices.map((service, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300 border-gray-200">
                <CardContent className="p-6 text-center">
                  <div className="mb-4">
                    <service.icon
                      className={`h-12 w-12 mx-auto ${service.color} group-hover:scale-110 transition-transform`}
                    />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{service.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">Why Choose HealthBot AI?</h2>
              <p className="text-lg text-gray-600 mb-8">
                Our advanced AI technology combines medical expertise with personalized care to provide you with
                accurate, timely, and actionable health information available 24/7.
              </p>

              <div className="grid gap-4">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-emerald-600 flex-shrink-0" />
                    <span className="text-gray-700 font-medium">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-6">
                <Card className="p-6 border-emerald-200">
                  <Users className="h-8 w-8 text-emerald-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-2">500K+ Users</h3>
                  <p className="text-sm text-gray-600">Trusted by healthcare seekers worldwide</p>
                </Card>
                <Card className="p-6 border-blue-200">
                  <Clock className="h-8 w-8 text-blue-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-2">24/7 Available</h3>
                  <p className="text-sm text-gray-600">Round-the-clock health support</p>
                </Card>
              </div>
              <div className="space-y-6 pt-8">
                <Card className="p-6 border-teal-200">
                  <Award className="h-8 w-8 text-teal-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-2">Medical Grade</h3>
                  <p className="text-sm text-gray-600">Evidence-based health information</p>
                </Card>
                <Card className="p-6 border-red-200">
                  <Heart className="h-8 w-8 text-red-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-2">Early Prevention</h3>
                  <p className="text-sm text-gray-600">Disease awareness and prevention</p>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Partners Section */}
      <section className="py-16 bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Trusted Health Resources</h3>
            <p className="text-gray-600">Powered by leading medical institutions and research organizations</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
            {partners.map((partner, index) => (
              <div key={index} className="text-center group">
                <div className="text-4xl mb-2 group-hover:scale-110 transition-transform">{partner.logo}</div>
                <p className="text-sm font-medium text-gray-700">{partner.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Get in Touch</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Connect with us through multiple channels. We're available 24/7 to support your health journey.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-8 text-center hover:shadow-lg transition-shadow">
              <div className="p-4 bg-green-100 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <MessageCircle className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">WhatsApp</h3>
              <p className="text-gray-600 mb-4">Chat with us instantly</p>
              <Button className="bg-green-600 hover:bg-green-700 w-full">Message on WhatsApp</Button>
            </Card>

            <Card className="p-8 text-center hover:shadow-lg transition-shadow">
              <div className="p-4 bg-blue-100 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Facebook className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Facebook</h3>
              <p className="text-gray-600 mb-4">Follow us for health tips</p>
              <Button
                variant="outline"
                className="border-blue-600 text-blue-600 hover:bg-blue-50 w-full bg-transparent"
              >
                Visit Facebook Page
              </Button>
            </Card>

            <Card className="p-8 text-center hover:shadow-lg transition-shadow">
              <div className="p-4 bg-pink-100 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Instagram className="h-8 w-8 text-pink-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Instagram</h3>
              <p className="text-gray-600 mb-4">Health content & updates</p>
              <Button
                variant="outline"
                className="border-pink-600 text-pink-600 hover:bg-pink-50 w-full bg-transparent"
              >
                Follow on Instagram
              </Button>
            </Card>
          </div>

          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">Available 24/7 for your health queries and support</p>
            <div className="flex items-center justify-center gap-2 text-emerald-600">
              <Clock className="h-5 w-5" />
              <span className="font-semibold">Round-the-clock availability</span>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-emerald-600 to-teal-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Ready to Transform Your Health Journey?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Join thousands of users who trust HealthBot AI for reliable health information and guidance - available
            24/7.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-emerald-600 hover:bg-gray-100 px-8 py-3 text-lg font-semibold">
              Start Free Consultation
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white hover:text-emerald-600 px-8 py-3 text-lg bg-transparent"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-emerald-600 rounded-lg">
                  <Stethoscope className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">HealthBot AI</h3>
                  <p className="text-gray-400 text-sm">Advanced Health Solutions</p>
                </div>
              </div>
              <p className="text-gray-400 mb-4 max-w-md">
                Empowering individuals with AI-driven health insights and disease awareness to make informed healthcare
                decisions. Available 24/7 for your health needs.
              </p>
              <div className="flex gap-4 mb-4">
                <Button
                  size="sm"
                  variant="outline"
                  className="border-gray-600 text-gray-400 hover:text-white hover:border-white bg-transparent"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  WhatsApp
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-gray-600 text-gray-400 hover:text-white hover:border-white bg-transparent"
                >
                  <Facebook className="h-4 w-4 mr-2" />
                  Facebook
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-gray-600 text-gray-400 hover:text-white hover:border-white bg-transparent"
                >
                  <Instagram className="h-4 w-4 mr-2" />
                  Instagram
                </Button>
              </div>
              <p className="text-xs text-gray-500">
                © 2024 HealthBot AI. This platform provides general health information only. Always consult healthcare
                professionals for medical advice.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Disease Awareness</li>
                <li>Early Prevention</li>
                <li>Symptom Assessment</li>
                <li>24/7 Health Support</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Help Center</li>
                <li>Medical Disclaimer</li>
                <li>Privacy Policy</li>
                <li>Contact Us</li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
